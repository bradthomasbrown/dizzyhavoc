export { Chart as default } from "$fresh_charts/island.tsx";
